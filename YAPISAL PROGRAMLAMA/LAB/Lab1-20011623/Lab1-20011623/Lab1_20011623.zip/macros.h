//
//  macros.h
//  Lab1-20011623
//
//  Created by Asude Ekiz on 1.11.2021.
//

#ifndef macros_h
#define macros_h

#define ITERATION 5
#define POPULATION 10



#endif /* macros_h */
